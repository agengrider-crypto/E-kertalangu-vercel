# Test Credentials

## Admin (seeded dari env saat bootstrap)
- Email: `agengpadma8@gmail.com`
- Username: `admin`
- Password: `jokam354`
- Role: `admin`

Sumber: `backend/.env` (`ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_USERNAME`, `ADMIN_PHONE`).
Di Vercel, set variabel yang sama di Project Settings -> Environment Variables.

## Peserta
Tidak ada akun peserta permanen. Suite regresi
`/app/backend/tests/test_vercel_regression.py` membuat & menghapus akun
peserta `TEST_` sendiri via `POST /api/users`.

## Base URL preview
`https://bsa-ubah-rute.preview.emergentagent.com`
